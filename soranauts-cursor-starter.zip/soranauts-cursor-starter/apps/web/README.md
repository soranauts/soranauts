# apps/web (Astro site)
Move your existing Astro project here. Keep current structure under `src/`.
Add /src/pages/tools/* as React islands where needed.
